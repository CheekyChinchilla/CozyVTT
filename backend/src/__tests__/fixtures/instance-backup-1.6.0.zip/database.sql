--
-- PostgreSQL database dump
--

-- Dumped from database version 15.19
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';

DROP TABLE IF EXISTS public."Note";
CREATE TABLE public."Note" (id text NOT NULL, body text);
ALTER TABLE public."Note" OWNER TO "cozyvttAdmin";
COPY public."Note" (id, body) FROM stdin;
a1	SET transaction_timeout = 0;
\.
CREATE TABLE public."User" (
    id text NOT NULL
);
CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL
);

--
-- PostgreSQL database dump complete
--
